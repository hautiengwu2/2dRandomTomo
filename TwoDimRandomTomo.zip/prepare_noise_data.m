% 
% prepare the image with purely noisy entries
%
% called by other functions
%

n_theta = 8192;

noiseimg = randn(101);
[x,y] = meshgrid(-50:50, -50:50);
r = sqrt(x.^2 + y.^2);
noiseimg(find(r > 50)) = 0;

theta   = rand(n_theta,1)*pi;
[theta,tmp] = sort(theta);
[X]     = radon(noiseimg, theta*360/(2*pi));
[n_t, tmp] = size(X);


snr     = 10^(snrdb/10);
Nsigma  = sqrt(var(X(:))/snr);
N       = randn(size(X))*Nsigma;
XN      = X+N;


%subplot(1,2,1); imagesc(headimg); axis image; colormap('gray');
%subplot(1,2,2); 
%{
imagesc(iradon(XN,theta*360/(2*pi))); axis equal; axis tight; axis off; 
colormap('gray'); 
if snrdb>0
    savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_known_abdrecon.png'],'png'); close;
else
    savefig(['m',num2str(abs(snrdb)),'_',num2str(SEED),'_known_abdrecon.png'],'png'); close;
end
close all;
%}
%pause;

if parameter.debug==1
    fprintf(['(DEBUG) snrdb=',num2str(snrdb),'; added noise Nsigma^2=',num2str(Nsigma^2),'\n']);
end


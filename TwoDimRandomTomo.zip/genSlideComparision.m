%
% generate comparison among PCA, Wiener, adaptive Wiener and wavelet for slides
%


clc; close all;


scrsz = get(0,'ScreenSize');

parameter.debug	= 1;

SEED	= 52;
CALLsnrdb	= [10 2 -1 -5] ;


for CALLii = 1:length(CALLsnrdb)

    initstate(SEED); 
    snrdb	= CALLsnrdb(CALLii); 
    prepare_phantom;




		%% run PCA (take the symmetry into account)
	PeXN    = (XN+flipud(XN))./sqrt(2);
	PeXN    = PeXN(1:ceil(n_t/2),:);    
	PoXN    = (XN-flipud(XN))./sqrt(2);
	PoXN    = PoXN(1:ceil(n_t/2),:);

	PCAcovEVEN  = cov(PeXN');
	[UPCEVEN,lambdaPCEVEN,ut]   = svd(PCAcovEVEN);
	if mod(size(XN,1),2)
	    UPCEVEN = [UPCEVEN; flipud(UPCEVEN(2:end,:))]./sqrt(2);
	else
	    UPCEVEN = [UPCEVEN; flipud(UPCEVEN)]./sqrt(2);
	end

	PCAcovODD   = cov(PoXN');
	[UPCODD,lambdaPCODD,ut] = svd(PCAcovODD);
	if mod(size(XN,1),2)
	    UPCODD = [UPCODD; -flipud(UPCODD(2:end,:))]./sqrt(2);  %% changed from : to 2:end
	else
	    UPCODD = [UPCODD; -flipud(UPCODD)]./sqrt(2);
	end
    UPC = [UPCEVEN UPCODD] ;
	lambdahat = [diag(lambdaPCEVEN)' diag(lambdaPCODD)']' ;


		%% run KN to determine the number of significant eigenvectors!
	[NOPCEVEN,sigmahat2EVEN] = KN_rankEst(diag(lambdaPCEVEN),n_theta,1,0.1,ceil(n_t/2));
	[NOPCODD,sigmahat2ODD] = KN_rankEst(diag(lambdaPCODD),n_theta,1,0.1,ceil(n_t/2));
	lambdaPCEVEN = diag(lambdaPCEVEN);
	lambdaPCODD = diag(lambdaPCODD);

	lambdaKN = [lambdaPCEVEN(1:NOPCEVEN); lambdaPCODD(1:NOPCODD)];
	UPCKN = [UPCEVEN(:,1:NOPCEVEN) UPCODD(:,1:NOPCODD)];
	NOPCKN = NOPCODD+NOPCEVEN;

		%% the estimated noise level by KN
	sigmahat2   = zeros(NOPCODD+NOPCEVEN,1);
	sigmahat2(1:NOPCEVEN) = sigmahat2EVEN;
	sigmahat2(NOPCEVEN+1:end) = sigmahat2ODD;

    mirrorsymmetry
 



		%% denoise the projection images by the ordinary Wiener filter
	mu  = mean(XN,2);
	yi  = UPC'*(XN-repmat(mu,1,n_theta));
    SNRi = lambdahat./mean(sigmahat2) ;
    xhati = diag(1./(1+1./SNRi))*yi;
	XDW = UPC*xhati+repmat(mu,1,n_theta);


		%% denoise the projection images by the ordinary Wiener filter
    	%% get the estimated, unbiased, eigenvalues ref: Johnstone or Nadler
	ygammai  = UPCKN'*(XN-repmat(mu,1,n_theta));
	lambdagammai = real(0.5* ( lambdaKN-(gamma+1).*sigmahat2+sqrt( (lambdaKN-(gamma+1).*sigmahat2).^2-4*sigmahat2.^2  )   ));

    	%% the "over-weighted" parameters for the Wiener filter
	ci2 	= (1-gamma*(sigmahat2./lambdagammai).^2)./(1+gamma*(sigmahat2./lambdagammai));
	SNRgammai    = ci2.*(lambdagammai./sigmahat2);
	xhatgammai   = diag(1./(1+1./SNRgammai))*ygammai;

    	%% denoised projection images
	XDadaW = UPCKN*xhatgammai+repmat(mu,1,n_theta);




	figure('Position',[1 scrsz(4)/2 scrsz(3) scrsz(4)]) ;
    	%% plot 4 projections. denoised by the "optimal Wiener filter"
    for jj = 1:4
        QQ = floor(min(size(XN,2), size(XN,1)*jj/3)) ; 
		Yval = 0.4 ; %
    	
		subplot(4, 4, jj+12) ;
        plot(X(:,QQ), 'k', 'linewidth', 1.5); hold on; plot(XDadaW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf -Yval+0.2 Yval]);
		set(gca, 'fontsize', 24) ;
		if jj == 1 ; ylabel('Adaptive\newlineWiener') ; end    

		subplot(4, 4, jj) ;
        plot(XN(:,QQ), 'linewidth', 1); hold on; plot(X(:,QQ), 'k', 'linewidth', 2); axis tight; axis([-inf inf -Yval+0.2 Yval]);
		set(gca, 'fontsize', 24) ;
		if jj == 1 ; ylabel('Noisy\newlineSignal') ; end    
		title(['\theta = ',num2str(floor(100*theta(QQ)/pi)/100),'\pi']) ;
		if jj == 1 ; title(['SNRdB = ',num2str(snrdb),'; \theta = ',num2str(floor(100*theta(QQ)/pi)/100),'\pi']) ; end
    
			%% ordinary Wiener
        subplot(4, 4, jj+4) ;
		plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf -Yval+0.2 Yval]); hold on; 
        plot(X(:,QQ), 'k', 'linewidth', 1.5); 
        set(gca, 'fontsize', 24) ;
        if jj == 1 ; ylabel('Ordinary\newlineWiener') ; end

			%% spin cyclic
        s = XN(:,QQ);
        ds = spincycle(s,snrdb,'db2');
    
		subplot(4, 4, jj+8) ;
		plot(ds,'red','linewidth',2); axis tight; axis([-inf inf -Yval+0.2 Yval]); hold on ; 
   	    plot(X(:,QQ), 'k', 'linewidth', 1.5); 
		set(gca, 'fontsize', 24) ;
		if jj == 1 ; ylabel('Spin\newlineCyclic') ; end    
    end
    savefig(['Slide',num2str(snrdb),'snr',num2str(CALLii),'.eps'],'eps'); 

end 

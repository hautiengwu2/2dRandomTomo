% This is the code modified from revise4.m to generate all the figures in the paper
% written by Hau-tieng Wu 2011, 6, 20
%% generate fig 4.6 and 4.7
clc; clear
parameter.debug = 0;
parameter.fig7_2 = 0;
parameter.fig7_11 = 0;

n_t = 128; 
n_theta = 1024;

t       = linspace(-1.5, 1.5, n_t);
theta   = linspace(0, pi, n_theta);
X       = shepp_logan_proj_2(theta, t);
Xs = [X flipud(X)];
n_theta = n_theta*2;

%img = phantom(128);
%Xs = radon(img, linspace(0, 360, n_theta));


NN      = floor(n_theta*2*(10/360));

PCAcov = cov(Xs');
[uclean,lambda,utclean] = svd(PCAcov);


for jjj = 2:5

    X = uclean(:,1:jjj)'*(Xs - repmat(mean(Xs,2), 1, n_theta)); 

%{
data=zeros(2,1500);
theta=linspace(0,2*pi,1500);
data(1,:)=cos(theta);
data(2,:)=sin(theta);
noise=randn(2,1500)/5;
change=(1+0.6*cos(theta(1:2:end)))/1.6;

data2=data;
data2(2,1:750)=data(2,1:750).*change;
data2(2,751:1500)=data(2,751:1500).*change;
X = data2 + 0*noise/2;
n_theta = 1500;
NN = 50;
%}

    atria           = nn_prepare(X');
    [index,distance]= nn_search(X',atria,[1:n_theta].',NN,-1,0.0);

    Th = quantile(distance(:,end),0.25);


    h = 0.001;
    h = quantile(distance(:,end).^2,0.12);
    for ii = 1:n_theta
	distance(ii, find(distance(ii,:)>1.5*sqrt(h))) = inf;
    end


    I = zeros(NN,n_theta); for k=1:NN; I(k,:)=1:n_theta; end; I=I(:);
    J = index.'; J = J(:);
    %Jdistance = ones(size(distance));
    Jdistance = exp(-5*(distance.^2/h)); Jdistance=Jdistance.';
    %Jdistance = exp(-5*(distance.^2./1000)); Jdistance=Jdistance.';

    W = sparse(I,J,Jdistance(:),n_theta,n_theta,n_theta*NN);
    W1 = W.*W';
        %% alpha=1
    v = sum(W1); v = v(:);
    V1 = sparse(1:length(v), 1:length(v), 1./v);
    W1 = V1*W1*V1;
    D = sum(W1); D = D(:);
    V2 = sparse(1:length(D), 1:length(D), sqrt(1./D));
    W2 = V2*W1*V2;
    W2 = (W2+W2')/2; %% artifically added.
    [UD, lambdaD, UDT] = svds(W2,'L');
    U = V2*UD; 
    lambdaD = diag(lambdaD);
    [lambdaD, lambdaDidx] = sort(lambdaD,'descend');
    U = U(:, lambdaDidx);

    thetahat1 = U(:,2);
    thetahat2 = U(:,3);

    plot(thetahat1(1:1024), thetahat2(1:1024), 'linewidth', 2);
    hold on;
    plot(thetahat1(1025:2048), thetahat2(1025:2048), 'linewidth', 2);
    axis image; axis off; axis tight
    %eval(['savefig(''embedding2dcleanR',num2str(jjj),'png.eps'',''eps''); close;']);
    %eval(['saveas(gca,''embedding2dcleanR',num2str(jjj),'png.eps'',''eps''); close;']);
end

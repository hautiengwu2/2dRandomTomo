% This is the code modified from revise4.m to generate all the figures in the paper
% written by Hau-tieng Wu 2011, 6, 20
%% generate fig 4.6 and 4.7
clc; clear
parameter.debug = 0;

n_t=512; 
n_theta=1024;

t       = linspace(-1.5,1.5,n_t);
theta   = linspace(1,2*pi,n_theta);
X       = shepp_logan_proj_2(theta,t);
Xs = [X flipud(X)];

PCAcov = cov(Xs');
[u,lambda,ut] = svd(PCAcov);

Xd = u(:,1:2)'* (Xs - repmat(mean(Xs,2), 1, n_theta*2));
plot(Xd(1,1:1024),Xd(2,1:1024),'linewidth',2); hold on;
plot(Xd(1,1025:2048),Xd(2,1025:2048),'linewidth',2);
axis off;
saveas(gca,'embedding2dcleanPCA.eps','eps'); close


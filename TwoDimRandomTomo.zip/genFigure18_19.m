% This is the code modified from revise4.m to generate all the figures in the paper
% Generate the figures 7.2 and figure 7.11
%
% written by Hau-tieng Wu 2011, 6, 20

close all; clear; clc;
parameter.debug		= 1;
parameter.maketex	= 0;
parameter.fig7_2	= 0;
parameter.fig7_11	= 0;

CALLsnrdb=[30 10 5 4 3];
CALLthrd=[50]/100;
CALLalpha=[6];


for CALLii = 4:length(CALLsnrdb)
    fprintf('\n');

    for SEED = 52:52

        fprintf('\n');
	initstate(540);
	snrdb	= CALLsnrdb(CALLii);
	prepare_abd_data;
	NN	= floor(2*n_theta*2*(CALLalpha(1)/360));
	AAthrd	= CALLthrd(1);

	ordinaryPCA;
	mirrorsymmetry;
	wienerfilter;

	X=xhati.'; 
	ReconImage;


        plot(theta(sorted_theta_idx),'linewidth',2);
        axis tight; set(gca,'fontsize',20);
        savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_optimal_angle.eps'],'eps'); close;

        imagesc(im1); colormap(gray); axis equal; axis tight; axis off;
        set(gca,'fontsize',20); %title([num2str(L1norm)]);
        savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_optimal_recon.eps'],'eps'); close;

    end
end


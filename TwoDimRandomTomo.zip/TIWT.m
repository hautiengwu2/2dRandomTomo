function [T,L]=TIWT(s,levels,IN3,IN4);
%
% [T,L]=TIWT(s,levels,wname);
% [T,L]=TIWT(s,levels,Lo_D,Hi_D);
%
% Construct a translation-invariant wavelet-tree.
%
% Input parameters:
%     s          Signal to decompose.
%     levels     Number of levels in the decomposition. A warning is issued
%                if larger than the number of allowable levels for the
%                given wavelet.     
%     wname      Name of wavelet to use in the decomposition. See wfilters.
%
% Output parameters:
%     T          Translation invariant wavelet coefficients.
%                These are stored in a 1D array since each level may have a
%                slightly different number of coefficients (if the length
%                of the signal is not dyadic). The (details) coefficients
%                are stored in the array from the coarsest level to the
%                finest (finest at the end). If the finest level (the
%                orginal signal) is J=log2(length(s)), then at level j we
%                have 2^(J-j-1)*2 coefficients (one set that corresponds to
%                S0 and one that corresponds to S1). These are ordered in
%                the array from k=2^(J-j-1)-1 to 0, where for each k alpha0
%                (the coefficient from S0) comes before alpha1 (the
%                coefficient from S1). Finally, at the begining of the
%                array there are the approximation coefficients of the
%                coarsest level. 
%                See "Translation Invariant De-Noising" by Coifman and
%                Donoho for more information.
%     L          Size of each level, from the coarsest to the finest.
%
% Yoel Shkolnisky, April 2007.

if nargin<1
    error('Signal must be provided');
end

if nargin<2
    error('Number of levels must be provided');
end

if nargin<3
    error('wavelet must be provided');
end

if nargin==3;
    [Lo_D,Hi_D] = wfilters(IN3,'d');
else
    Lo_D=IN3; 
    Hi_D=IN4;
end


s=s(:);
n=size(s,1);
max_level=fix(log(n/(length(Lo_D)-1))/log(2));

if levels>max_level
    levels=max_level;
    warning(sprintf('level is too large. Setting levels=%d.',max_level));
end

J=floor(log2(n));
beta=s;
beta0=s;
T=[];
L=n;

for j=J-1:-1:J-levels  
    c=L(1);
    beta_next=[];
    for k=2^(J-j-1)-1:-1:0
        coeffs=beta(k*c+1:(k+1)*c);

        [beta0,alpha0] = dwt(coeffs,Lo_D,Hi_D);
        [beta1,alpha1] = dwt([coeffs(2:end) ; coeffs(1)],Lo_D,Hi_D);

        T=[alpha0 ; alpha1 ; T];
        beta_next=[ beta0; beta1 ; beta_next];
    end
    beta=beta_next;
    L=[length(beta0) ; L];
end
T=[beta ; T];
L=[length(beta0) ; L];

%
% PCA+KN with mirror symmetries taken into consideration
% 
% Hau-tieng Wu, 2011-07-19
%

PeXN	= (XN+flipud(XN))./sqrt(2);
PeXN	= PeXN(1:ceil(n_t/2),:);	%% changed from nothing to ceil
PoXN	= (XN-flipud(XN))./sqrt(2);
PoXN	= PoXN(1:ceil(n_t/2),:);

PCAcovEVEN	= cov(PeXN');
[UPCEVEN,lambdaPCEVEN,ut]	= svd(PCAcovEVEN);
[NOPCEVEN,sigmahat2EVEN]	= KN_rankEst(diag(lambdaPCEVEN),n_theta,1,0.1,ceil(n_t/2));
if mod(size(XN,1),2)
    UPCEVEN		= [UPCEVEN; flipud(UPCEVEN(2:end,:))]./sqrt(2);
else
    UPCEVEN		= [UPCEVEN; flipud(UPCEVEN)]./sqrt(2);
end
lambdaPCEVEN	= diag(lambdaPCEVEN);

PCAcovODD	= cov(PoXN');
[UPCODD,lambdaPCODD,ut]		= svd(PCAcovODD);
[NOPCODD,sigmahat2ODD]		= KN_rankEst(diag(lambdaPCODD),n_theta,1,0.1,ceil(n_t/2));
if mod(size(XN,1),2)
    UPCODD		= [UPCODD; -flipud(UPCODD(2:end,:))]./sqrt(2);  %% changed from : to 2:end
else
    UPCODD		= [UPCODD; -flipud(UPCODD)]./sqrt(2); 
end
lambdaPCODD	= diag(lambdaPCODD);


lambdaPC	= [lambdaPCEVEN(1:NOPCEVEN); lambdaPCODD(1:NOPCODD)];
UPCshrinkage	= [UPCEVEN(:,1:NOPCEVEN) UPCODD(:,1:NOPCODD)];


	%% lambdaPC for plot
lambdaPCforPlot	= [lambdaPCEVEN lambdaPCODD] ;


	%% sigmahat2 should be a constant vector
sigmahat2	= zeros(NOPCODD+NOPCEVEN,1);
sigmahat2(1:NOPCEVEN)		= sigmahat2EVEN;
sigmahat2(NOPCEVEN+1:end)	= sigmahat2ODD;
NOPC		= NOPCODD+NOPCEVEN;


if parameter.debug==1
    fprintf(['(DEBUG) KN: number of chosen PCs, ODD=',num2str(NOPCODD),'\tEVEN=',num2str(NOPCEVEN),'\tnoise=',num2str(mean(sigmahat2)),'\n']);
end

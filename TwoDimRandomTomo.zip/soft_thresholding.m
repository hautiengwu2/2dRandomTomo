function ds=soft_thresholding(s,snr,wname)
%
% Soft thresholding denoising.
%
% Input parameters
%    s       Signal
%    wname   Wavelet
%
% Output parameters
%    ds      Denoised signal.
%
%dwtmode('sym');

s=s(:);
n=size(s,1);
levels=wmaxlev(n,wname);
threshold=sqrt(2*log(n))*sqrt(var(s)/snr);

[C,L]=wavedec(s,levels,wname);

y = max(abs(C(L(1)+1:length(s)))-threshold, 0);
C(L(1)+1:length(s)) = y./(y+threshold) .* C(L(1)+1:length(s));

ds=waverec(C,L,wname);

%{
L=s;

for ii=1:levels
    [L,W{ii}]=dwt(L,'db2');
    fprintf([num2str(size(L)),' ',num2str(size(W{ii})),'\n']);
end
W{levels+1}=L;

for ii=1:levels
    y = max(abs(W{ii})-threshold, 0);
    W{ii} = y./(y+threshold) .* W{ii};
end

L=idwt(W{levels+1},W{levels},'db2');
for ii=-levels:-2
    fprintf([num2str(size(L)),' ',num2str(size(W{-ii-1})),'\n']);
    L=idwt(L,W{-ii-1},'db2');
end

ds=L;
%}


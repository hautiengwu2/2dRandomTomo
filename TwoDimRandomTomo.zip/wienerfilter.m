%
% More aggresive Wiener filter taking the transition phenomenon of the eigenvector estimation into account
% 
% Hau-tieng Wu, 2011-07-19
%

mu	= mean(XN,2);
gamma	= 2*n_t/n_theta;


	%% get the estimated, unbiased, eigenvalues
fprintf('Estimate lambda by the original KN+MP\n') ;
fprintf('Run adaptive Wiener filter\n') ;
lambdahat = real(0.5* ( lambdaPC-(gamma+1).*sigmahat2+sqrt( (lambdaPC-(gamma+1).*sigmahat2).^2-4*sigmahat2.^2  )   ));
%UPCshrinkage = UPCKN ;


	%% adaptive Wiener filter
lambdaPCMP = zeros(size(lambdaPCforPlot)) ;
lambdaPCMP(1:NOPCEVEN) = lambdahat(1:NOPCEVEN) ;
lambdaPCMP(length(lambdaPCEVEN)+1:length(lambdaPCEVEN)+NOPCODD) = lambdahat(NOPCEVEN+1:NOPCEVEN+NOPCODD) ;


fprintf(' ***** Run ordinary Wiener filter\n') ;
lambdaPCMP = zeros(size(lambdaPCforPlot)) ;
lambdaPCMP(1:NOPCEVEN) = lambdaPC(1:NOPCEVEN) ;
lambdaPCMP(length(lambdaPCEVEN)+1:length(lambdaPCEVEN)+NOPCODD) = lambdaPC(NOPCEVEN+1:NOPCEVEN+NOPCODD) ;



figure(3) ; IDX = [1:30 256+1:256+30] ;
subplot(2,4,CALLii) ;
plot(lambdaPCforPlot(IDX)) ; hold on; plot(lambdaPCMP(IDX),'r','linewidth', 2) ; axis tight;
set(gca,'fontsize',20);
title([num2str(snrdb),'dB\newline',num2str(NOPCEVEN),'+',num2str(NOPCODD),' eigenvalues left']) ; legend('original', 'KN+MP') ; axis([-inf inf 0 8]) ;



	%%
fprintf(['KN+MP: number of chosen PCs, ODD=',num2str(NOPCODD),'\tEVEN=',num2str(NOPCEVEN),'\tnoise=',num2str(mean(sigmahat2)),'\n']);


yi	= UPCshrinkage'*(XN-repmat(mu,1,n_theta));
sigmahat2 = mean(sigmahat2) ;

	%% the "over-weighted" parameters for the Wiener filter
ci2	= (1-gamma*(sigmahat2./lambdahat).^2)./(1+gamma*(sigmahat2./lambdahat));
SNRi	= ci2.*(lambdahat./sigmahat2);
xhati	= diag(1./(1+1./SNRi))*yi;

	%% denoised projection images
XDW	= UPCshrinkage*xhati+repmat(mu,1,n_theta);
XDW = XDW * Nsigma ; % normalize back
XN = XN * Nsigma ; % normalize back

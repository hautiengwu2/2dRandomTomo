% This is the code modified from revise4.m to generate all the figures in the paper
% written by Hau-tieng Wu 2011, 6, 20
%% generate fig 4.6 and 4.7
clc; clear
parameter.debug = 0;

n_t=512; 
n_theta=1024;

SEED = 53;
initstate(53);
snrdb=8;

prepare_abd_data;
ordinaryPCA;
mirrorsymmetry;

PCAcovN=cov(XN');
[uN,lambdaN,utN]=svd(PCAcovN);
[NOPC,sigmahat2] = KN_rankEst(diag(lambdaN),n_theta,1,0.1,n_t);

PCAcov=cov(X');
[u,lambda,ut]=svd(PCAcov);

for jj=1:8
    autx=cov(u(:,jj),uN(:,jj));
    if autx(1,2)<0
	u(:,jj)=-u(:,jj); 
    end
end

for jj=1:8
    plot(u(:,jj)); axis tight;
    set(gca,'xtick',[]); set(gca,'ytick',[]);
    savefig(['abd_pc_clean_',num2str(jj),'.eps'],'eps'); close;
end
    
for jj=1:8
    plot(uN(:,jj)); axis tight;
    set(gca,'xtick',[]); set(gca,'ytick',[]);
    savefig(['abd_pc_8db_',num2str(jj),'.eps'],'eps'); close
end

%
% generate fig 7.9 and 7.10-- the denoised projections.
% 
% Hau-tieng Wu, 2011-07-19
%


clc; close all;

parameter.debug	= 1;
parameter.fig7_9	= 1;

SEED	= 52;
CALLsnrdb	= [2 1 0 -1];	%% fig 7.9 snrdb=2; fig 7.10 snrdb=-1

for CALLii=1:length(CALLsnrdb)

    initstate(SEED); 
    snrdb	= CALLsnrdb(CALLii); 
    
    prepare_phantom;
    NN      = floor(2*n_theta*2*(6/360));
    
    	%% plot 4 projections. denoised by the spin-cyclic soft thresholding
    XDW = zeros(size(X));
    for jj=1:n_theta
        fprintf('%6d',jj);
        s  = XN(:,jj); 
	ds = spincycle(s,snrdb,'db2');
	XDW(:,jj) = ds;
	fprintf('\b\b\b\b\b\b');
    end
	
    X = XDW.';
    atria           = nn_prepare(X);
    [index,distance]= nn_search(X,atria,[1:n_theta].',NN,-1,0.0);

    I=zeros(NN,n_theta); for k=1:NN; I(k,:)=1:n_theta; end; I=I(:);
    J=index.'; J=J(:);

    Jdistance=ones(size(distance));
    W1=sparse(I,J,Jdistance(:),n_theta,n_theta,n_theta*NN);

    v=sum(W1); v=v(:);
    V=sparse(1:length(v),1:length(v),sqrt(1./v));
    W1 = V*W1*V;
    D = sqrt(sum(W1)); D = D(:);
    V2 = sparse(1:length(D), 1:length(D), 1./D);
    W2 = V2*W1*V2;
    W2 = (W2+W2')/2; %% artifically added.

    [UD,lambdaD,UDT] = svds(W2);
    UD = V2*UD; 
    lambdaD = diag(lambdaD);
    [lambdaD,lambdaDidx] = sort(lambdaD,'descend');
    UD = UD(:, lambdaDidx);

    embedded_theta = atan2(UD(:,3),UD(:,2));
    [sorted_theta, sorted_theta_idx] = sort(embedded_theta);

    Xs = XN(:,index1(sorted_theta_idx(1:1:end)));
    equalangles = length(sorted_theta_idx(1:1:end));

% pick equally spaced angles
    equal_angles=(0:2*pi/equalangles:2*pi*(1-1/equalangles))*180/pi;
 

    plot(theta(sorted_theta_idx),'linewidth',2);
    axis tight; set(gca,'fontsize',20);
keyboard
    if snrdb>0
        savefig(['p',num2str(abs(snrdb)),'_amit_angle.eps'],'eps'); close;
    else
        savefig(['m',num2str(abs(snrdb)),'_amit_angle.eps'],'eps'); close;
    end

    P = Xs(:,1:1:end);
    im1 = iradon(P,equal_angles);

    imagesc(im1); colormap(gray); axis equal; axis tight; axis off;
    set(gca,'fontsize',20); 
    if snrdb>0
        savefig(['p',num2str(abs(snrdb)),'_amit_recon.eps'],'eps'); close;
    else
        savefig(['m',num2str(abs(snrdb)),'_amit_recon.eps'],'eps'); close;
    end


   
end % the end for the for loop

%
% this is called by other functison
%	Lafon alpha=1
%


distance = zeros(n_theta) ;
for ii = 1 : n_theta
    for jj = ii+1 : n_theta
        distance(ii, jj) = norm(xhati(:, ii) - xhati(:, jj)) ;
        distance(jj, ii) = distance(ii, jj) ;
    end
end

epsilon = quantile(distance(:), .5) ;
W = exp(-5*(distance.^2./epsilon)) ;
W = W - diag(diag(W)) ;


    %% alpha=0
v  = sum(W).^0; v = v(:);
V  = sparse(1:length(v), 1:length(v), sqrt(1./v));
W1 = V * W * V;
D  = sqrt(sum(W1)); D = D(:);
V2 = sparse(1:length(D), 1:length(D), 1./D);
W2 = V2 * W1 * V2;
W2 = (W2 + W2') / 2; %% artifically added.


[UD,lambdaD,UDT] = svds(W2);

UD = V*UD; lambdaD = diag(lambdaD);
[lambdaD, lambdaDidx] = sort(lambdaD,'descend');
UD = UD(:,lambdaDidx);

embedded_theta = atan2(UD(:,3),UD(:,2));
[sorted_theta, sorted_theta_idx] = sort(embedded_theta);

Xs = XN(:, sorted_theta_idx);
Nangles = length(sorted_theta_idx);




% pick equally spaced angles
equal_angles = (0:2*pi/Nangles:2*pi*(1-1/Nangles))*180/pi;

plot(theta(sorted_theta_idx),'linewidth',2);
axis tight; set(gca,'fontsize',20);
%if snrdb>0
%    savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_new_angle_direct.png'],'png','-lossless'); close;
%else
%    savefig(['m',num2str(abs(snrdb)),'_',num2str(SEED),'_new_angle_direct.png'],'png','-lossless'); close;
%end
    
P = Xs(:,1:1:end);
im1 = iradon(P, equal_angles);


imagesc(im1); colormap(gray); axis equal; axis tight; axis off;
set(gca,'fontsize',20); %title([num2str(L1norm)]);
%if snrdb>0
%    savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_new_recon_direct.png'],'png'); close;
%else
%    savefig(['m',num2str(abs(snrdb)),'_',num2str(SEED),'_new_recon_direct.png'],'png'); close;
%end

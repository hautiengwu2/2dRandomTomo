%
% generate fig 7.9 and 7.10-- the denoised projections.
% 
% Hau-tieng Wu, 2011-07-19
%


clc; close all;

parameter.debug	= 1;
parameter.fig7_9	= 0;

SEED	= 52;
CALLsnrdb	= [2 -1 -5];	%% fig 7.9 snrdb=2; fig 7.10 snrdb=-1


for CALLii=2:length(CALLsnrdb)

    initstate(SEED); 
    snrdb	= CALLsnrdb(CALLii); 
    
    prepare_phantom;
    ordinaryPCA;
    mirrorsymmetry
    wienerfilter;
    %getRMSE;
    
    if parameter.fig7_9
    	%% plot 4 projections. denoised by the "optimal Wiener filter"
        for jj=1:4
    	    QQ=min(size(XN,2), size(XN,1)*jj); RR=zeros(size(XN,1),2); 
    	    RR(:,1)=X(:,QQ); RR(:,2)=XN(:,QQ); Yval=max(RR(:));
    
            close all; 
    	    plot(X(:,QQ)); hold on; plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf -Yval Yval]);
    	    set(gca,'xtick',[]); set(gca,'ytick',[]);
            savefig(['cleanpca',num2str(snrdb),'snr',num2str(jj),'.eps'],'eps'); close all;
    
    	    plot(XN(:,QQ)); hold on; plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf -Yval Yval]);
    	    set(gca,'xtick',[]); set(gca,'ytick',[]);
            savefig(['pca',num2str(snrdb),'snr',num2str(jj),'.png'],'png','-lossless'); close all;
        end
    

    	%% plot 4 projections. denoised by the spin-cyclic soft thresholding
   	XDW = zeros(size(X));
        MSE = 0;
	for jj=1:n_theta
	    fprintf('%6d',jj);
	    s	    = XN(:,jj); 
	    ds	    = spincycle(s,snrdb,'db2');
            MSE     = MSE+norm(ds-X(:,jj));
	    fprintf('\b\b\b\b\b\b');
	end
	
    	RMSE        = sqrt(MSE/n_theta);

        for jj=1:4
    	    QQ=512*jj;
            s=XN(:,QQ);
            ds=spincycle(s,snrdb,'db2');
            RR=zeros(512,2); RR(:,1)=X(:,QQ); RR(:,2)=XN(:,QQ); Yval=max(RR(:));
    
            close all; 
    	    plot(X(:,QQ)); hold on; plot(ds,'red','linewidth',2); axis tight; axis([-inf inf -Yval Yval]);
    	    set(gca,'xtick',[]); set(gca,'ytick',[]);
            savefig(['cleanspin',num2str(snrdb),'snr',num2str(jj),'.eps'],'eps'); close all;
    
            plot(XN(:,QQ)); hold on; plot(ds,'red','linewidth',2); axis tight; axis([-inf inf -Yval Yval]);
    	    set(gca,'xtick',[]); set(gca,'ytick',[]);
            savefig(['spin',num2str(snrdb),'snr',num2str(jj),'.eps'],'eps'); close all;
        end

    end
    
end % the end for the for loop

function ds=spincycle(s,snrdb,wname)
%
% Spin cycle denoising.
%
% Input parameters
%    s       Signal do denoise.
%    snr     Estimation of the SNR of the noisy signal. Used to find cutoff
%            threshold for the expansion coefficients.
%    wname   Wavelet to use for the expansion. See wfilters.
%
% Output parameters
%    ds      Denoised signal.
%
% Example:
%    n=500;
%    t=linspace(-5,5,n);
%    S=exp(-t.^2);
%    v=var(S);
%    snr=20;
%    N=randn(1,n)*sqrt(v/snr);
%    S=S+N;
%    ds=spincycle(S,snr,'db2');
%    clf; plot(S); hold on; plot(ds,'r'); hold off;
%
% Yoel Shkolnisky, April 2007.

if nargin<2
    snrdb=1;
end

if nargin<3
    wname='haar';
end;

s=s(:);
n=size(s,1);
levels=wmaxlev(n,wname);
snr=10^(snrdb/10);
Nsigma=sqrt(var(s)/snr); 

threshold=sqrt(2*log(n))*Nsigma;
%threshold=sqrt(2*log(n))*sqrt(var(s)/snr);
[Lo_D,Hi_D,Lo_R,Hi_R] = wfilters(wname);

[T,L]=TIWT(s,levels,Lo_D,Hi_D);
%[T,L]=TIWT(s,levels,wname);
idx=2^(levels-1)*L(1)*2+1:length(T);
T(idx)=wthresh(T(idx),'h',threshold);
ds=ITIWT(T,L,Lo_R,Hi_R);
%ds=ITIWT(T,L,wname);

clc

SEED=53;

parameter.debug=1;
CALLsnrdb=[200000000000]; 


    initstate(SEED);
    snrdb   = CALLsnrdb(1);
    prepare_abd_data;

    ordinaryPCA;
    mirrorsymmetry;

    PCAcov=cov(XN');
    [u,lambda,ut]=svd(PCAcov);
    lambda=diag(lambda);  

    close all; bar(lambda(1:50)); axis tight; set(gca,'fontsize',20);
    savefig('abd_ev.eps','eps');

    imagesc(abdimg); colormap('gray'); axis image; axis off;
    savefig('abd_image.eps','eps');

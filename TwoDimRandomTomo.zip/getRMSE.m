%
% called by other functions
%

    MSE = 0;
    for jj=1:n_theta
        MSE     = MSE+norm(XDW(:,jj)-X(:,jj));
    end
    RMSE        = sqrt(MSE/n_theta);

    if parameter.debug
        fprintf(['(DEBUG) PCA version: RMSE of snrdb=',num2str(snrdb),' is ',num2str(RMSE),'\n']);
    end


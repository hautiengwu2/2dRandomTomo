function s=ITIWT(T,L,IN3,IN4);
%
% s=ITIWT(T,L,wname);
% s=ITIWT(T,L,Lo_R,Hi_R);
%
% Reconstruct a signal from a translation-invariant wavelet tree.
%
% T and L are the translation-invariant wavelet tree and the bookkeeping
% vector are returned from the function TIWT.
%
% See TIWT for more information. 
%
% Yoel Shkolnisky, April 2007.

if nargin<1
    error('Invariant wavelet tree must be provided. See TIWT for more information on the data structures.');
end

if nargin<2
    error('Bookkeeping vector must be provided. See TIWT for more information on the data structures.');
end

if nargin<3
    error('wavelet must be provided.');
end

if nargin==3;
    [Lo_R,Hi_R] = wfilters(IN3,'r');
else
    Lo_R=IN3; 
    Hi_R=IN4;
end

levels=length(L)-2;
n=L(end);
J=floor(log2(n));

beta=T(1:2^(levels-1)*L(1)*2);
T=T(2^(levels-1)*L(1)*2+1:end);
idx=2;
for j=J-levels:J-1
    beta_next=[];
    for k=0:2^(J-j-1)-1

        alpha0=T(2*k*L(idx)+1:(2*k+1)*L(idx));
        alpha1=T((2*k+1)*L(idx)+1:(2*k+2)*L(idx));
                    
        beta0=beta(2*k*L(idx)+1:(2*k+1)*L(idx));
        beta1=beta((2*k+1)*L(idx)+1:(2*k+2)*L(idx));

        tmp1=idwt(beta0,alpha0,Lo_R,Hi_R);
        tmp1=tmp1(1:L(idx+1));
        tmp2=idwt(beta1,alpha1,Lo_R,Hi_R);
        tmp2=tmp2(1:L(idx+1));
        tmp2=[tmp2(end) ; tmp2(1:end-1)];

        beta_next=[beta_next ; (tmp1(:)+tmp2(:))/2];        

    end
    T=T(2^(J-j)*L(idx)+1:end);
    idx=idx+1;
    beta=beta_next;
end

s=beta;
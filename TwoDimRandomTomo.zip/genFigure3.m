% This is the code modified from revise4.m to generate all the figures in the paper
% Generate the figures 7.2 and figure 7.11
%
% written by Hau-tieng Wu 2011, 6, 20

close all; clear; clc;

CALLsnrdb=[300000 0 -2 -5 -10];

for CALLii = 1:length(CALLsnrdb)

    snrdb   = CALLsnrdb(CALLii);
    n_t     = 512;
    n_theta = 1024;

    t       = linspace(-1.5,1.5,n_t);
    theta   = linspace(0,2*pi,n_theta);
    X       = shepp_logan_proj_2(theta,t);

    snr     = 10^(snrdb/10);
    Nsigma  = sqrt(var(X(:))/snr);
    N       = randn(size(X))*Nsigma;
    XN      = X+N;

    phantom = iradon(XN, theta*360/(2*pi));
    imagesc(phantom); axis image; axis off; colormap('gray');

    if CALLii == 1
	savefig(['cleanphantom.eps'],'eps')
    else
        eval(['savefig([''m',num2str(-snrdb),'phantom.eps''],''eps'');']);
    end
end


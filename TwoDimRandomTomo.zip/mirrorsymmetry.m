%
% called by other functions
%

X0      = [X0 flipud(X0)];
XN      = [XN flipud(XN)];
theta   = [theta; mod(theta+pi,2*pi)];
[theta,thetaidx] = sort(theta);
XN      = XN(:,thetaidx);
X0      = X0(:,thetaidx);
n_theta = 2*n_theta;


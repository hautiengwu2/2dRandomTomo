%
% this is called by other functison
%	Lafon alpha=1
%


atria		= nn_prepare(X);
[index,distance]= nn_search(X,atria,[1:n_theta].',NN,-1,0.0);

I=zeros(NN,n_theta); for k=1:NN; I(k,:)=1:n_theta; end; I=I(:);
J=index.'; J=J(:);

GraphDenoise;

    %% alpha=1
v=sum(W1); v=v(:);
V=sparse(1:length(v),1:length(v),sqrt(1./v));
W1 = V*W1*V;
D = sqrt(sum(W1)); D = D(:);
V2 = sparse(1:length(D), 1:length(D), 1./D);
W2 = V2*W1*V2;
W2=(W2+W2')/2; %% artifically added.


if parameter.debug==1; fprintf('(DEBUG) start to estimate eigenvectors...'); end
[UD,lambdaD,UDT]=svds(W2);
if parameter.debug==1; fprintf(' DONE!\n'); end

UD=V*UD; lambdaD=diag(lambdaD);
[lambdaD,lambdaDidx]=sort(lambdaD,'descend');
UD=UD(:,lambdaDidx);

embedded_theta=atan2(UD(:,3),UD(:,2));
[sorted_theta,sorted_theta_idx]=sort(embedded_theta);

Xs=XN(:,index1(sorted_theta_idx(1:1:end)));
equalangles=length(sorted_theta_idx(1:1:end));

% pick equally spaced angles
equal_angles=(0:2*pi/equalangles:2*pi*(1-1/equalangles))*180/pi;

if parameter.fig7_2
    plot(theta(sorted_theta_idx),'linewidth',2);
    axis tight; set(gca,'fontsize',20);
    if snrdb>0
        savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_new_angle_direct.png'],'png','-lossless'); close;
    else
        savefig(['m',num2str(abs(snrdb)),'_',num2str(SEED),'_new_angle_direct.png'],'png','-lossless'); close;
    end
end
    
P=Xs(:,1:1:end);
im1=iradon(P,equal_angles);


%im1=im1/norm(im1,'fro');
%[L1a,L1b]=wavedec2(im1,4,'db2');
%L1norm=sum(abs(L1a));


if parameter.fig7_2
    imagesc(im1); colormap(gray); axis equal; axis tight; axis off;
    set(gca,'fontsize',20); %title([num2str(L1norm)]);
pause(0.5);
    if snrdb>0
        savefig(['p',num2str(abs(snrdb)),'_',num2str(SEED),'_new_recon_direct.png'],'png'); close;
    else
        savefig(['m',num2str(abs(snrdb)),'_',num2str(SEED),'_new_recon_direct.png'],'png'); close;
    end
end


%
% this is called by reconstruction.m
%	use the weight matrix for Jaccard
%

if parameter.debug; fprintf(['(DEBUG) Jaccard graph denoise starts\n']); end

Jdistance=ones(size(distance));

W=sparse(I,J,Jdistance(:),n_theta,n_theta,n_theta*NN);


    %UPDATE% plot figure for the paper
if parameter.fig7_11 & snrdb==-4
    gplot(W(1:2:end,1:2:end),[sin(theta(1:2:end)) cos(theta(1:2:end))])
    axis equal; axis off;
    savefig('noisygraph.eps','eps'); close all;
end

if parameter.debug; fprintf(['(DEBUG) Generate information matrix for Jaccard denoise\n']); end

jaccard = (W*W')./ (W*ones(n_theta,1)*ones(1,n_theta) + ones(n_theta,1)*ones(1,n_theta)*W' - W*W');

W1=zeros(size(W));
W1(find(jaccard>=AAthrd))=W(find(jaccard>=AAthrd));
index1=find(sum(W1)>1);

    %% plot figure for the paper
if parameter.fig7_11 & snrdb==-4
    gplot(W1(1:2:end,1:2:end),[sin(theta(1:2:end)) cos(theta(1:2:end))])
    axis equal; axis off;
    savefig('denoisedgraph.eps','eps'); close all
end

if parameter.debug
    fprintf(['(DEBUG) number of non-singular vertices=',num2str(length(index1)),' out of ',num2str(n_theta),'\n']);
end

W1=W1(index1,index1);

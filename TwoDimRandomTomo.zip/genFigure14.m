% This is the code modified from revise4.m to generate all the figures in the paper
% Generate the figures 7.2 and figure 7.11
%
% written by Hau-tieng Wu 2011, 6, 20

close all; clear; clc;
parameter.debug		= 1;
parameter.fig7_2	= 0;
parameter.fig7_11	= 1;

CALLsnrdb=[-4];
CALLthrd=[50]/100;
CALLalpha=[6];


for CALLii = 1:length(CALLsnrdb)
    fprintf('\n');

    for SEED = 52:52

        fprintf('\n');
	initstate(SEED);
	snrdb	= CALLsnrdb(CALLii);
	prepare_phantom;
	NN	= floor(2*n_theta*2*(CALLalpha(1)/360));
	AAthrd	= CALLthrd(1);

	ordinaryPCA;
	mirrorsymmetry;
	wienerfilter;

	X=xhati.'; 
	ReconImage;

    end
end


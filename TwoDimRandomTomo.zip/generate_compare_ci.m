clc
addpath('/u/hauwu/code_old/2dpaper');
addpath('/u/hauwu/code_old/random_projection');

n_t=512; 
n_theta=1024;
seedno=500;
count=0; totalRMSE=0; totalRMSEc=0;
snrdb=-2;

for SEED=1:seedno

n_theta=1024;
fprintf('%6d',SEED);
initstate(SEED);

t=linspace(-1.5,1.5,n_t);
theta=rand(n_theta,1)*2*pi;
[theta]=sort(theta);
X=shepp_logan_proj_2(theta,t);
snr=10^(snrdb/10);
Nsigma=sqrt(var(X(:))/snr); 

N=randn(size(X))*Nsigma;
XN=X+N;         

ordinaryPCA3;

X=[X flipud(X)];
XN=[XN flipud(XN)];
theta=[theta; mod(theta+pi,2*pi)];
[theta,thetaidx]=sort(theta);
XN=XN(:,thetaidx);
X=X(:,thetaidx);
n_theta=2*n_theta;

mu=mean(XN,2);
yi=UPCKN'*(XN-repmat(mu,1,n_theta));
gamma=n_t/n_theta; 
lambdahat=real(0.5* ( lambdaPC-(gamma+1).*sigmahat2+sqrt( (lambdaPC-(gamma+1).*sigmahat2).^2-4*sigmahat2.^2  )   ));
ci2=(1-gamma*(sigmahat2./lambdahat).^2)./(1+gamma*(sigmahat2./lambdahat));
SNRi=ci2.*(lambdahat./sigmahat2);
xhatiW=diag(1./(1+1./SNRi))*yi;%+diag(1./(1+SNRi))*repmat(mui,1,size(XN,2));
XDW=UPCKN*xhatiW+repmat(mu,1,n_theta);

ci2=1;
SNRi=ci2.*(lambdahat./sigmahat2);
xhatiW=diag(1./(1+1./SNRi))*yi;
XDW2=UPCKN*xhatiW+repmat(mu,1,n_theta);


MSEc=0;
for jj=1:n_theta; MSEc=MSEc+norm(XDW(:,jj)-X(:,jj)); end
RMSEc=sqrt(MSEc/n_theta); totalRMSEc=totalRMSEc+RMSEc;

MSE=0;
for jj=1:n_theta; MSE=MSE+norm(XDW2(:,jj)-X(:,jj)); end
RMSE=sqrt(MSE/n_theta); totalRMSE=totalRMSE+RMSE;
clear X; clear XN; clear XDW; clear XDW2; clear xhatiW; clear lambdahat; clear sigmahat2; clear SNRi; 

if RMSE>RMSEc; count=count+1; end
fprintf(['RMSE of snrdb=',num2str(snrdb),' is ',num2str(RMSE),'\t']);
fprintf(['RMSEc of snrdb=',num2str(snrdb),' is ',num2str(RMSEc),'\n']);

end

fprintf(['noise=',num2str(snrdb),'\tnew filter is better in ',num2str(count),'/',num2str(seedno),' seeds; RMSE=',num2str(totalRMSE/seedno),'; RMSEc=',num2str(totalRMSEc/seedno),'\n']);

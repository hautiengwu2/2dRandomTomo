mu      = mean(XN,2);
XN = XN - repmat(mu, 1, n_theta) ;

PeXN    = (XN+flipud(XN))./sqrt(2);
PeXN    = PeXN(1:ceil(n_t/2),:);        %% changed from nothing to ceil
PoXN    = (XN-flipud(XN))./sqrt(2);
PoXN    = PoXN(1:ceil(n_t/2),:);
gamma = n_t ./ n_theta ./ 2 ;

PeXN = PeXN ./ sqrt(n_theta) ;
PoXN = PoXN ./ sqrt(n_theta) ;
[ae,be,ce] = svd(PeXN) ;
[ao,bo,co] = svd(PoXN) ;
lambdaOSe = diag(be) ;
lambdaOSo = diag(bo) ;

if OptimalShrinkageOpt == 2

	fprintf('Estimate lambda by the optimal Frobenius\n') ;

        idxe = find(lambdaOSe >= 1+sqrt(gamma)) ;
	lambdaQe = zeros(size(lambdaOSe)) ;
        lambdaOSe2 = lambdaOSe(idxe) ;
        lambdahate = sqrt((lambdaOSe2.^2 - gamma - 1).^2 - 4*gamma) ./ lambdaOSe2 ;
	lambdaQe(idxe) = lambdahate ;	

        idxo = find(lambdaOSo >= 1+sqrt(gamma)) ;
        lambdaQo = zeros(size(lambdaOSo)) ;
        lambdaOSo2 = lambdaOSo(idxo) ;
        lambdahato = sqrt((lambdaOSo2.^2 - gamma - 1).^2 - 4*gamma) ./ lambdaOSo2 ;
        lambdaQo(idxo) = lambdahato ;

elseif OptimalShrinkageOpt == 3

	fprintf('Estimate lambda by the optimal Operator\n') ;

        idxe = find(lambdaOSe >= 1+sqrt(gamma)) ;
        lambdaQe = zeros(size(lambdaOSe)) ;
        lambdaOSe2 = lambdaOSe(idxe) ;
	xye = sqrt(lambdaOSe2.^2-gamma-1+sqrt((lambdaOSe2.^2-gamma-1).^2-4*gamma)) ./ sqrt(2) ;
	lambdaQe(idxe) = xye ;	

        idxo = find(lambdaOSo >= 1+sqrt(gamma)) ;
        lambdaQo = zeros(size(lambdaOSo)) ;
        lambdaOSo2 = lambdaOSo(idxo) ;
        xyo = sqrt(lambdaOSo2.^2-gamma-1+sqrt((lambdaOSo2.^2-gamma-1).^2-4*gamma)) ./ sqrt(2) ;
        lambdaQo(idxo) = xyo ;   


elseif OptimalShrinkageOpt == 4

	fprintf('Estimate lambda by the optimal Nuclear\n') ;

	lambdaQe = zeros(size(lambdaOSe)) ;
        idxe = find(lambdaOSe >= 1+sqrt(gamma)) ;
        lambdaOSe2 = lambdaOSe(idxe) ;
        xye = sqrt(lambdaOSe2.^2-gamma-1+sqrt((lambdaOSe2.^2-gamma-1).^2-4*gamma)) ./ sqrt(2) ;

	idxe2 = find(xye.^4 >= gamma + sqrt(gamma)*xye.*lambdaOSe2) ;
	xye = xye(idxe2) ;
	lambdaOSe2 = lambdaOSe2(idxe2) ;
	lambdahate = (xye.^4 - gamma - sqrt(gamma)*xye.*lambdaOSe2) ./ (lambdaOSe2 .* xye.^2) ;
	idxe = idxe(idxe2) ;
	lambdaQe(idxe) = lambdahate ;


        lambdaQo = zeros(size(lambdaOSo)) ;
        idxo = find(lambdaOSo >= 1+sqrt(gamma)) ;
        lambdaOSo2 = lambdaOSo(idxo) ;
        xyo = sqrt(lambdaOSo2.^2-gamma-1+sqrt((lambdaOSo2.^2-gamma-1).^2-4*gamma)) ./ sqrt(2) ;

        idxo2 = find(xyo.^4 >= gamma + sqrt(gamma)*xyo.*lambdaOSo2) ;
        xyo = xyo(idxo2) ;
        lambdaOSo2 = lambdaOSo2(idxo2) ;
        lambdahato = (xyo.^4 - gamma - sqrt(gamma)*xyo.*lambdaOSo2) ./ (lambdaOSo2 .* xyo.^2) ;
        idxo = idxo(idxo2) ;
        lambdaQo(idxo) = lambdahato ;

else
	error(['No such option...\n'])
end
	

	%% plot the result
	%% square the singular values for the comparison purpose (with our PCA)
figure(3) ;
subplot(2,4,CALLii) ;
plot([lambdaOSe(1:30).^2; lambdaOSo(1:30).^2]) ; hold on; plot([lambdaQe(1:30).^2; lambdaQo(1:30).^2],'r','linewidth', 2) ; axis tight;
set(gca,'fontsize',20);
title([num2str(snrdb),'dB\newline',num2str(length(idxo)),'+',num2str(length(idxe)),' eigenvalues left']) ; legend('original', OptimalShrinkageName{OptimalShrinkageOpt}) ; axis([-inf inf 0 8]) ;

fprintf(['Total ',num2str(length(idxe)),'+',num2str(length(idxo)),' eigenvalues left after ',OptimalShrinkageName{OptimalShrinkageOpt},' OS']) ;




        %% denoised projection images
Lambdae = zeros(n_t/2, n_theta) ; Lambdae(1:n_t/2, 1:n_t/2) = diag(lambdaQe) ;
Lambdao = zeros(n_t/2, n_theta) ; Lambdao(1:n_t/2, 1:n_t/2) = diag(lambdaQo) ;
XDWe     = sqrt(n_theta) * ae * Lambdae * ce' ;
XDWo     = sqrt(n_theta) * ao * Lambdao * co' ;

XDWe = [XDWe; flipud(XDWe)] ;
XDWo = [XDWo; -flipud(XDWo)] ;
XDW = Nsigma * ((XDWe + XDWo) ./ sqrt(2) + repmat(mu, 1, n_theta));
XN = Nsigma * (XN + repmat(mu, 1, n_theta)) ;

	%% find the features
if mod(size(XN,1),2)
    ae = [ae; flipud(ae(2:end,:))]./sqrt(2);
    ao = [ao; -flipud(ao(2:end,:))]./sqrt(2);
else
    ae = [ae; flipud(ae)]./sqrt(2);
    ao = [ao; -flipud(ao)]./sqrt(2);
end

X0      = [X0 flipud(X0)];
XN      = [XN flipud(XN)];
theta   = [theta; mod(theta+pi,2*pi)];
[theta,thetaidx] = sort(theta);
XN      = XN(:,thetaidx);
X0      = X0(:,thetaidx);
n_theta = 2*n_theta;

xhatie = ae(:, idxe)' * XN ;
xhatio = ao(:, idxo)' * XN ;
xhati = [xhatie; xhatio] ;

clc

SEED=53;

parameter.debug=1;
CALLsnrdb=[20 2 1 0 -1 -2 -5 -10];

for ii=1:8

    initstate(SEED);
    snrdb   = CALLsnrdb(ii);
    prepare_phantom;

    ordinaryPCA;
    mirrorsymmetry;

    PCAcov=cov(XN');
    [u,lambda,ut]=svd(PCAcov);
    lambda=diag(lambda);  

    close all; bar(lambda(1:20)); axis tight; set(gca,'fontsize',20);

    if snrdb==20
        savefig('bar-20.eps','eps');
    elseif snrdb==2
        savefig('bar-2.eps','eps');
    elseif snrdb==1
        savefig('bar-1.eps','eps');
    else
        savefig(['bar-m',num2str(abs(snrdb)),'.eps'],'eps');
    end

end

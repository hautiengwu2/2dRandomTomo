% 
% prepare phantom
%
% called by other functions
%

n_t	= 512;
n_theta = 1024;

t	= linspace(-1.5,1.5,n_t);
theta	= rand(n_theta,1)*2*pi;
[theta]	= sort(theta);
X0	= shepp_logan_proj_2(theta,t);


snr     = 10^(snrdb/10);
Nsigma  = sqrt(var(X0(:))/snr);
N       = randn(size(X0))*Nsigma;
XN      = X0 + N ;

fprintf(['(DEBUG) snrdb=',num2str(snrdb),'; added noise Nsigma^2=',num2str(Nsigma^2),'\n']);



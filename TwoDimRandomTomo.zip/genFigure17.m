%
% generate fig 7.9 and 7.10-- the denoised projections.
% 
% Hau-tieng Wu, 2011-07-19
%


clc; close all;

parameter.debug	= 1;
parameter.fig7_9	= 1;

SEED	= 52;
CALLsnrdb = [8];


for CALLii=1:length(CALLsnrdb)

    initstate(SEED); 
    snrdb	= CALLsnrdb(CALLii); 
    
    prepare_abd_data;
    ordinaryPCA;
    mirrorsymmetry
    wienerfilter;
    getRMSE;
    
    for jj=1:4
    	QQ=min(size(XN,2), size(XN,1)*jj); RR=zeros(size(XN,1),2); 
   	RR(:,1)=X(:,QQ); RR(:,2)=XN(:,QQ); Yval=max(RR(:));

        close all; 
    	plot(X(:,QQ)); hold on; plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf -Yval Yval]);
    	set(gca,'xtick',[]); set(gca,'ytick',[]);
        savefig(['abdcleanpca',num2str(snrdb),'snr',num2str(jj),'.eps'],'eps'); close all;
    
    	plot(XN(:,QQ)); hold on; plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf -Yval Yval]);
        set(gca,'xtick',[]); set(gca,'ytick',[]);
        savefig(['abdpca',num2str(snrdb),'snr',num2str(jj),'.eps'],'eps'); close all;
    end
    
end % the end for the for loop

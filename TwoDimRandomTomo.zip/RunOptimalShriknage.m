% This is the code modified from revise4.m to generate all the figures in the paper
% Generate the figures 7.2 and figure 7.11
%
% written by Hau-tieng Wu 2011, 6, 20

close all; clear; clc;
SEED = 152 ;
parameter.debug		= 1;
parameter.fig7_2	= 0;
parameter.fig7_11	= 0;

CALLsnrdb=[2 1 0 -1 -2 -3 -4 -5];
CALLthrd=[50]/100;
CALLalpha=[6];


OptimalShrinkageOpt = 1 ;
OptimalShrinkageName = {'KN+MP', 'Frobenius', 'Operator', 'Nuclear'} ;

for CALLii = 1:length(CALLsnrdb)
    fprintf('\n');

	initstate(SEED) ;
	snrdb	= CALLsnrdb(CALLii);
	prepare_phantom;
	XN	= XN ./ Nsigma ;
	NN	= floor(2*n_theta*2*(CALLalpha(1)/360));
	AAthrd	= CALLthrd(1);

	if OptimalShrinkageOpt == 1
		ordinaryPCA;
		mirrorsymmetry;
		wienerfilter;
	else
		OptimalShrinkage;
	end

	X=xhati.'; 
	ReconImage;

	figure(1) ;
	subplot(2,4,CALLii) ;
        plot(theta(sorted_theta_idx),'linewidth',2);
        axis tight; set(gca,'fontsize',20); title([num2str(snrdb),'dB']) ;

	figure(2) ;
	subplot(2,4,CALLii) ;
        imagesc(im1); colormap(gray); axis equal; axis tight; axis off;
        set(gca,'fontsize',20); title([num2str(snrdb),'dB']) ;


	figure(4) ; QQ=1;
	subplot(2,4,1*(CALLii-1)+1) ;
        RR(:,1)=X0(:,QQ); RR(:,2)=XDW(:,QQ); Yval=max(RR(:)); Zval=min(RR(:));
        plot(X0(:,QQ)); hold on; plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf Zval Yval]);
        set(gca,'xtick',[]); set(gca,'ytick',[]); set(gca,'fontsize',20);
	title([num2str(snrdb),'dB']) ;

	%subplot(4,4,2*(CALLii-1)+2) ;
        %plot(XN(:,QQ)); hold on; plot(XDW(:,QQ),'red','linewidth',2); axis tight; axis([-inf inf Zval Yval]);
        %set(gca,'xtick',[]); set(gca,'ytick',[]); set(gca,'fontsize',20);
	%title([num2str(snrdb),'dB']) ;

end

figure(1) ;
text(-3000,+7.4, [OptimalShrinkageName{OptimalShrinkageOpt},' Random Seed = ',num2str(SEED)],'fontsize',20,'color','r')

figure(2) ;
text(-700,-160, [OptimalShrinkageName{OptimalShrinkageOpt},' Random Seed = ',num2str(SEED)],'fontsize',20,'color','r')

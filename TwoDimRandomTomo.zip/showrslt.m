load rslt_optimal_m5
rslt=rsltm5;
for qq=1:1
    fprintf(['snrdb=',num2str(rslt(qq).snrdb),'\n']);    
    fprintf(['mean of alpha=',num2str(mean(rslt(qq).optimalalpha)),'; std of alpha=',num2str(std(rslt(qq).optimalalpha)),'\n'])    
    fprintf(['mean of beta=',num2str(mean(rslt(qq).optimalgamma)),'; std of beta=',num2str(std(rslt(qq).optimalgamma)),'\n'])    
    fprintf(['mean of L1=',num2str(mean(rslt(qq).optimalL1)),'; std of L1=',num2str(std(rslt(qq).optimalL1)),'\n'])    
    fprintf(['mean of RMSE=',num2str(mean(rslt(qq).optimalRMSE)),'; std of L1=',num2str(std(rslt(qq).optimalRMSE)),'\n'])
end


load rslt_optimal_p10

for qq=1:2
    fprintf(['snrdb=',num2str(rslt(qq).snrdb),'\n']);
    fprintf(['mean of alpha=',num2str(mean(rslt(qq).optimalalpha)),'; std of alpha=',num2str(std(rslt(qq).optimalalpha)),'\n'])
    fprintf(['mean of beta=',num2str(mean(rslt(qq).optimalgamma)),'; std of beta=',num2str(std(rslt(qq).optimalgamma)),'\n'])
    fprintf(['mean of L1=',num2str(mean(rslt(qq).optimalL1)),'; std of L1=',num2str(std(rslt(qq).optimalL1)),'\n'])
    fprintf(['mean of RMSE=',num2str(mean(rslt(qq).optimalRMSE)),'; std of L1=',num2str(std(rslt(qq).optimalRMSE)),'\n'])
end



load rslt_optimal_p3

for qq=1:2
    fprintf(['snrdb=',num2str(rslt(qq).snrdb),'\n']);
    fprintf(['mean of alpha=',num2str(mean(rslt(qq).optimalalpha)),'; std of alpha=',num2str(std(rslt(qq).optimalalpha)),'\n'])
    fprintf(['mean of beta=',num2str(mean(rslt(qq).optimalgamma)),'; std of beta=',num2str(std(rslt(qq).optimalgamma)),'\n'])
    fprintf(['mean of L1=',num2str(mean(rslt(qq).optimalL1)),'; std of L1=',num2str(std(rslt(qq).optimalL1)),'\n'])
    fprintf(['mean of RMSE=',num2str(mean(rslt(qq).optimalRMSE)),'; std of L1=',num2str(std(rslt(qq).optimalRMSE)),'\n'])
end






load rslt_optimal_p1

for qq=1:2
    fprintf(['snrdb=',num2str(rslt(qq).snrdb),'\n']);
    fprintf(['mean of alpha=',num2str(mean(rslt(qq).optimalalpha)),'; std of alpha=',num2str(std(rslt(qq).optimalalpha)),'\n'])
    fprintf(['mean of beta=',num2str(mean(rslt(qq).optimalgamma)),'; std of beta=',num2str(std(rslt(qq).optimalgamma)),'\n'])
    fprintf(['mean of L1=',num2str(mean(rslt(qq).optimalL1)),'; std of L1=',num2str(std(rslt(qq).optimalL1)),'\n'])
    fprintf(['mean of RMSE=',num2str(mean(rslt(qq).optimalRMSE)),'; std of L1=',num2str(std(rslt(qq).optimalRMSE)),'\n'])
end

load rslt_optimal_m1

for qq=1:2
    fprintf(['snrdb=',num2str(rslt(qq).snrdb),'\n']);
    fprintf(['mean of alpha=',num2str(mean(rslt(qq).optimalalpha)),'; std of alpha=',num2str(std(rslt(qq).optimalalpha)),'\n'])
    fprintf(['mean of beta=',num2str(mean(rslt(qq).optimalgamma)),'; std of beta=',num2str(std(rslt(qq).optimalgamma)),'\n'])
    fprintf(['mean of L1=',num2str(mean(rslt(qq).optimalL1)),'; std of L1=',num2str(std(rslt(qq).optimalL1)),'\n'])
    fprintf(['mean of RMSE=',num2str(mean(rslt(qq).optimalRMSE)),'; std of L1=',num2str(std(rslt(qq).optimalRMSE)),'\n'])
end


load rslt_optimal_m3

for qq=1:2
    fprintf(['snrdb=',num2str(rslt(qq).snrdb),'\n']);
    fprintf(['mean of alpha=',num2str(mean(rslt(qq).optimalalpha)),'; std of alpha=',num2str(std(rslt(qq).optimalalpha)),'\n'])
    fprintf(['mean of beta=',num2str(mean(rslt(qq).optimalgamma)),'; std of beta=',num2str(std(rslt(qq).optimalgamma)),'\n'])
    fprintf(['mean of L1=',num2str(mean(rslt(qq).optimalL1)),'; std of L1=',num2str(std(rslt(qq).optimalL1)),'\n'])
    fprintf(['mean of RMSE=',num2str(mean(rslt(qq).optimalRMSE)),'; std of L1=',num2str(std(rslt(qq).optimalRMSE)),'\n'])
end

